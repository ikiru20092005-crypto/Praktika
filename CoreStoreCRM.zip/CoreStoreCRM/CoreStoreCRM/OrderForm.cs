﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CoreStoreCRM
{
    public partial class OrderForm : Form
    {
        private int selectedOrderId = 0;
        public OrderForm()
        {
            InitializeComponent();
        }
        private void OrderForm_Load(object sender, EventArgs e)
        {
            // Проверка сессии
            if (!AppSession.IsAuthenticated)
            {
                MessageBox.Show("Требуется авторизация!");
                this.Close();
                return;
            }

            LoadOrders();
            LoadAvailableProducts();
            LoadComboBoxes();
        }

        private void LoadOrders()
        {
            using (MySqlConnection conn = DBConnection.GetConnection())
            {
                conn.Open();
                string sql = "SELECT * FROM v_order_details";

                MySqlDataAdapter adapter = new MySqlDataAdapter(sql, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                dgvOrders.DataSource = dt;
            }
        }

        private void LoadComboBoxes()
        {
            // Статусы
            using (MySqlConnection conn = DBConnection.GetConnection())
            {
                conn.Open();

                MySqlDataAdapter daStatus = new MySqlDataAdapter("SELECT orderStatusId, name FROM OrderStatus", conn);
                DataTable dtStatus = new DataTable();
                daStatus.Fill(dtStatus);
                cmbStatus.DataSource = dtStatus;
                cmbStatus.DisplayMember = "name";
                cmbStatus.ValueMember = "orderStatusId";

                // Сотрудники
                MySqlDataAdapter daEmp = new MySqlDataAdapter("SELECT employeeId, fullName FROM Employee", conn);
                DataTable dtEmp = new DataTable();
                daEmp.Fill(dtEmp);
                cmbEmployee.DataSource = dtEmp;
                cmbEmployee.DisplayMember = "fullName";
                cmbEmployee.ValueMember = "employeeId";
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            using (MySqlConnection conn = DBConnection.GetConnection())
            {
                conn.Open();

                using (MySqlCommand cmd = new MySqlCommand("sp_create_order", conn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@p_address", txtAddress.Text);
                    cmd.Parameters.AddWithValue("@p_userId", AppSession.UserId);
                    cmd.Parameters.AddWithValue("@p_currencyId", 1);
                    cmd.Parameters.AddWithValue("@p_productId", 1); // Упрощенно

                    var result = cmd.ExecuteScalar();
                    MessageBox.Show($"Создан заказ №{result}");
                    LoadOrders();
                }
            }
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedOrderId == 0)
            {
                MessageBox.Show("Выберите заказ!");
                return;
            }

            using (MySqlConnection conn = DBConnection.GetConnection())
            {
                conn.Open();
                string sql = @"UPDATE `Order` 
                              SET address = @address, amount = @amount, 
                                  orderStatusId = @statusId, employeeId = @empId 
                              WHERE orderId = @id";

                using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@id", selectedOrderId);
                    cmd.Parameters.AddWithValue("@address", txtAddress.Text);
                    cmd.Parameters.AddWithValue("@amount", decimal.Parse(txtAmount.Text));
                    cmd.Parameters.AddWithValue("@statusId", cmbStatus.SelectedValue);
                    cmd.Parameters.AddWithValue("@empId", cmbEmployee.SelectedValue);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Заказ обновлен!");
                    LoadOrders();
                }
            }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedOrderId == 0)
            {
                MessageBox.Show("Выберите заказ!");
                return;
            }

            if (MessageBox.Show("Удалить заказ?", "Подтверждение", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                using (MySqlConnection conn = DBConnection.GetConnection())
                {
                    conn.Open();
                    string sql = "DELETE FROM `Order` WHERE orderId = @id";

                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", selectedOrderId);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Заказ удален!");
                        LoadOrders();
                    }
                }
            }
        }
        private void LoadAvailableProducts()
        {
            try
            {
                using (MySqlConnection conn = DBConnection.GetConnection())
                {
                    conn.Open();
                    string sql = "SELECT * FROM Product";

                    MySqlDataAdapter adapter = new MySqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    MessageBox.Show($"Найдено товаров: {dt.Rows.Count}\n" +
                                  $"Столбцы: {string.Join(", ", dt.Columns.Cast<DataColumn>().Select(c => c.ColumnName))}\n" +
                                  $"Первый товар: {(dt.Rows.Count > 0 ? dt.Rows[0]["name"] : "нет")}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}\n\n{ex.StackTrace}");
            }
        }
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadOrders();
        }

        private void dgvOrders_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                selectedOrderId = Convert.ToInt32(dgvOrders.Rows[e.RowIndex].Cells["orderId"].Value);
                txtAddress.Text = dgvOrders.Rows[e.RowIndex].Cells["address"].Value?.ToString();
                txtAmount.Text = dgvOrders.Rows[e.RowIndex].Cells["amount"].Value?.ToString();
            }
        }
    }
}

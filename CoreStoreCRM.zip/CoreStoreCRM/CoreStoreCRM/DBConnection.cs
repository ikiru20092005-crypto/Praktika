﻿using MySql.Data.MySqlClient;

namespace CoreStoreCRM
{
    public static class DBConnection
    {
        private const string ConnString =
            "Server=localhost;Database=corestorecrm;Uid=root;Pwd=;Charset=utf8mb4;";

        public static MySqlConnection GetConnection()
        {
            return new MySqlConnection(ConnString);
        }
    }
}
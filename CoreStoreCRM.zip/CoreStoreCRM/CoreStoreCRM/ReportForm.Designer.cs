﻿namespace CoreStoreCRM
{
    partial class ReportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitle = new Label();
            dgvReport = new DataGridView();
            btnViewOrders = new Button();
            btnViewStats = new Button();
            btnInnerJoin = new Button();
            btnLeftJoin = new Button();
            btnRightJoin = new Button();
            btnGroupBy = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvReport).BeginInit();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            lblTitle.Location = new Point(12, 9);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(169, 21);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Отчеты и аналитика";
            // 
            // dgvReport
            // 
            dgvReport.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvReport.Location = new Point(209, 30);
            dgvReport.Name = "dgvReport";
            dgvReport.Size = new Size(579, 408);
            dgvReport.TabIndex = 1;
            // 
            // btnViewOrders
            // 
            btnViewOrders.Location = new Point(12, 30);
            btnViewOrders.Name = "btnViewOrders";
            btnViewOrders.Size = new Size(191, 40);
            btnViewOrders.TabIndex = 2;
            btnViewOrders.Text = "Заказы с деталями (VIEW)";
            btnViewOrders.UseVisualStyleBackColor = true;
            btnViewOrders.Click += button1_Click;
            // 
            // btnViewStats
            // 
            btnViewStats.Location = new Point(12, 76);
            btnViewStats.Name = "btnViewStats";
            btnViewStats.Size = new Size(191, 40);
            btnViewStats.TabIndex = 3;
            btnViewStats.Text = "Статистика обращений (VIEW)";
            btnViewStats.UseVisualStyleBackColor = true;
            btnViewStats.Click += btnViewStats_Click;
            // 
            // btnInnerJoin
            // 
            btnInnerJoin.Location = new Point(12, 122);
            btnInnerJoin.Name = "btnInnerJoin";
            btnInnerJoin.Size = new Size(191, 40);
            btnInnerJoin.TabIndex = 4;
            btnInnerJoin.Text = "INNER JOIN";
            btnInnerJoin.UseVisualStyleBackColor = true;
            btnInnerJoin.Click += btnInnerJoin_Click;
            // 
            // btnLeftJoin
            // 
            btnLeftJoin.Location = new Point(12, 168);
            btnLeftJoin.Name = "btnLeftJoin";
            btnLeftJoin.Size = new Size(191, 40);
            btnLeftJoin.TabIndex = 5;
            btnLeftJoin.Text = "LEFT JOIN";
            btnLeftJoin.UseVisualStyleBackColor = true;
            btnLeftJoin.Click += btnLeftJoin_Click;
            // 
            // btnRightJoin
            // 
            btnRightJoin.Location = new Point(12, 214);
            btnRightJoin.Name = "btnRightJoin";
            btnRightJoin.Size = new Size(191, 40);
            btnRightJoin.TabIndex = 6;
            btnRightJoin.Text = "RIGHT JOIN";
            btnRightJoin.UseVisualStyleBackColor = true;
            btnRightJoin.Click += btnRightJoin_Click;
            // 
            // btnGroupBy
            // 
            btnGroupBy.Location = new Point(12, 260);
            btnGroupBy.Name = "btnGroupBy";
            btnGroupBy.Size = new Size(191, 40);
            btnGroupBy.TabIndex = 7;
            btnGroupBy.Text = "GROUP BY + HAVING";
            btnGroupBy.UseVisualStyleBackColor = true;
            btnGroupBy.Click += btnGroupBy_Click;
            // 
            // ReportForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnGroupBy);
            Controls.Add(btnRightJoin);
            Controls.Add(btnLeftJoin);
            Controls.Add(btnInnerJoin);
            Controls.Add(btnViewStats);
            Controls.Add(btnViewOrders);
            Controls.Add(dgvReport);
            Controls.Add(lblTitle);
            Name = "ReportForm";
            Text = "ReportForm";
            Load += ReportForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvReport).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitle;
        private DataGridView dgvReport;
        private Button btnViewOrders;
        private Button btnViewStats;
        private Button btnInnerJoin;
        private Button btnLeftJoin;
        private Button btnRightJoin;
        private Button btnGroupBy;
    }
}
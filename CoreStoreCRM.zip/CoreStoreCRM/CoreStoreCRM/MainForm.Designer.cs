﻿namespace CoreStoreCRM
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblWelcome = new Label();
            lblUserInfo = new Label();
            btnOrders = new Button();
            btnAppeals = new Button();
            btnReports = new Button();
            btnUsers = new Button();
            btnReferences = new Button();
            btnLogout = new Button();
            panelStats = new Panel();
            lblOrderCount = new Label();
            lblAppealCount = new Label();
            SuspendLayout();
            // 
            // lblWelcome
            // 
            lblWelcome.AutoSize = true;
            lblWelcome.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            lblWelcome.Location = new Point(15, 12);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(163, 21);
            lblWelcome.TabIndex = 0;
            lblWelcome.Text = "Добро пожаловать";
            // 
            // lblUserInfo
            // 
            lblUserInfo.AutoSize = true;
            lblUserInfo.Location = new Point(15, 42);
            lblUserInfo.Name = "lblUserInfo";
            lblUserInfo.Size = new Size(125, 15);
            lblUserInfo.TabIndex = 1;
            lblUserInfo.Text = "Пользователь: [роль]";
            // 
            // btnOrders
            // 
            btnOrders.Location = new Point(15, 271);
            btnOrders.Name = "btnOrders";
            btnOrders.Size = new Size(214, 40);
            btnOrders.TabIndex = 2;
            btnOrders.Text = "Заказы";
            btnOrders.UseVisualStyleBackColor = true;
            btnOrders.Click += btnOrders_Click;
            // 
            // btnAppeals
            // 
            btnAppeals.Location = new Point(15, 225);
            btnAppeals.Name = "btnAppeals";
            btnAppeals.Size = new Size(214, 40);
            btnAppeals.TabIndex = 3;
            btnAppeals.Text = "Обращения";
            btnAppeals.UseVisualStyleBackColor = true;
            btnAppeals.Click += btnAppeals_Click;
            // 
            // btnReports
            // 
            btnReports.Location = new Point(15, 133);
            btnReports.Name = "btnReports";
            btnReports.Size = new Size(214, 40);
            btnReports.TabIndex = 4;
            btnReports.Text = "Отчеты";
            btnReports.UseVisualStyleBackColor = true;
            btnReports.Click += btnReports_Click;
            // 
            // btnUsers
            // 
            btnUsers.Font = new Font("Segoe UI", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            btnUsers.Location = new Point(154, 75);
            btnUsers.Name = "btnUsers";
            btnUsers.Size = new Size(75, 53);
            btnUsers.TabIndex = 5;
            btnUsers.Text = "Пользователи";
            btnUsers.UseVisualStyleBackColor = true;
            btnUsers.Click += btnUsers_Click;
            // 
            // btnReferences
            // 
            btnReferences.Location = new Point(15, 179);
            btnReferences.Name = "btnReferences";
            btnReferences.Size = new Size(214, 40);
            btnReferences.TabIndex = 6;
            btnReferences.Text = "Справочники";
            btnReferences.UseVisualStyleBackColor = true;
            btnReferences.Click += btnReferences_Click;
            // 
            // btnLogout
            // 
            btnLogout.Location = new Point(15, 317);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(214, 75);
            btnLogout.TabIndex = 7;
            btnLogout.Text = "Выход";
            btnLogout.UseVisualStyleBackColor = true;
            btnLogout.Click += btnLogout_Click;
            // 
            // panelStats
            // 
            panelStats.BorderStyle = BorderStyle.FixedSingle;
            panelStats.Location = new Point(235, 12);
            panelStats.Name = "panelStats";
            panelStats.Size = new Size(553, 380);
            panelStats.TabIndex = 8;
            panelStats.Paint += panelStats_Paint;
            // 
            // lblOrderCount
            // 
            lblOrderCount.AutoSize = true;
            lblOrderCount.Location = new Point(15, 66);
            lblOrderCount.Name = "lblOrderCount";
            lblOrderCount.Size = new Size(94, 15);
            lblOrderCount.TabIndex = 9;
            lblOrderCount.Text = "Всего заказов: 0";
            // 
            // lblAppealCount
            // 
            lblAppealCount.AutoSize = true;
            lblAppealCount.Location = new Point(15, 94);
            lblAppealCount.Name = "lblAppealCount";
            lblAppealCount.Size = new Size(118, 15);
            lblAppealCount.TabIndex = 10;
            lblAppealCount.Text = "Всего обращений: 0";
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(794, 398);
            Controls.Add(lblAppealCount);
            Controls.Add(lblOrderCount);
            Controls.Add(panelStats);
            Controls.Add(btnLogout);
            Controls.Add(btnReferences);
            Controls.Add(btnUsers);
            Controls.Add(btnReports);
            Controls.Add(btnAppeals);
            Controls.Add(btnOrders);
            Controls.Add(lblUserInfo);
            Controls.Add(lblWelcome);
            Name = "MainForm";
            Text = "MainForm";
            Load += MainForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblWelcome;
        private Label lblUserInfo;
        private Button btnOrders;
        private Button btnAppeals;
        private Button btnReports;
        private Button btnUsers;
        private Button btnReferences;
        private Button btnLogout;
        private Panel panelStats;
        private Label lblOrderCount;
        private Label lblAppealCount;
    }
}
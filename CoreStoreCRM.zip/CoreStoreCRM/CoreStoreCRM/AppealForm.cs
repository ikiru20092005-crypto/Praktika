﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CoreStoreCRM
{
    public partial class AppealForm : Form
    {
        private int selectedAppealId = 0;

        public AppealForm()
        {
            InitializeComponent();
        }

        private void AppealForm_Load(object sender, EventArgs e)
        {
            LoadAppeals();
            LoadTypes();
        }

        private void LoadAppeals()
        {
            using (MySqlConnection conn = DBConnection.GetConnection())
            {
                conn.Open();
                string sql = @"SELECT a.appealId, a.description, ast.name as status, 
                                      at.name as type, u.name as client, a.closeDate
                               FROM Appeal a
                               JOIN AppealStatus ast ON a.appealStatusId = ast.appealStatusId
                               JOIN AppealType at ON a.appealTypeId = at.appealTypeId
                               JOIN `User` u ON a.userId = u.userId";

                MySqlDataAdapter adapter = new MySqlDataAdapter(sql, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvAppeals.DataSource = dt;
            }
        }

        private void LoadTypes()
        {
            using (MySqlConnection conn = DBConnection.GetConnection())
            {
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT appealTypeId, name FROM AppealType", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                cmbType.DataSource = dt;
                cmbType.DisplayMember = "name";
                cmbType.ValueMember = "appealTypeId";
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            using (MySqlConnection conn = DBConnection.GetConnection())
            {
                conn.Open();
                string sql = @"INSERT INTO Appeal (description, appealStatusId, userId, appealTypeId) 
                              VALUES (@desc, 1, @userId, @typeId)";

                using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@desc", txtDescription.Text);
                    cmd.Parameters.AddWithValue("@userId", AppSession.UserId);
                    cmd.Parameters.AddWithValue("@typeId", cmbType.SelectedValue);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Обращение создано!");
                    LoadAppeals();
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (selectedAppealId == 0)
            {
                MessageBox.Show("Выберите обращение!");
                return;
            }

            using (MySqlConnection conn = DBConnection.GetConnection())
            {
                conn.Open();

                using (MySqlCommand cmd = new MySqlCommand("sp_close_appeal", conn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@p_appealId", selectedAppealId);
                    cmd.Parameters.AddWithValue("@p_employeeId", AppSession.UserId);

                    try
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Обращение закрыто!");
                        LoadAppeals();
                    }
                    catch (MySqlException ex)
                    {
                        MessageBox.Show($"Ошибка: {ex.Message}");
                    }
                }
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadAppeals();
        }

        private void dgvAppeals_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                selectedAppealId = Convert.ToInt32(dgvAppeals.Rows[e.RowIndex].Cells["appealId"].Value);
                txtDescription.Text = dgvAppeals.Rows[e.RowIndex].Cells["description"].Value?.ToString();
            }
        }
    }
}

﻿namespace CoreStoreCRM
{
    public static class AppSession
    {
        public static int? UserId { get; set; }
        public static string CurrentUserName { get; set; }
        public static int? RoleId { get; set; }

        public static bool IsAuthenticated => UserId.HasValue;
        public static bool IsAdmin => RoleId == 4;

        public static string CurrentRoleName => RoleId switch
        {
            1 => "Клиент",
            2 => "Менеджер",
            3 => "Руководитель",
            4 => "Администратор",
            _ => "Неизвестно"
        };

        public static void Logout()
        {
            UserId = null;
            CurrentUserName = null;
            RoleId = null;
        }
    }
}
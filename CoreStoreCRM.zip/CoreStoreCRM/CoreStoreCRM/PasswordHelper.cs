﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace CoreStoreCRM
{
    public static class PasswordHelper
    {
        public static string GenerateSalt()
        {
            byte[] salt = new byte[16];
            using (var rng = RandomNumberGenerator.Create())
                rng.GetBytes(salt);
            return Convert.ToHexString(salt).ToLower();
        }

        public static string HashPassword(string password, string salt)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(salt + password));
                return Convert.ToHexString(hash).ToLower();
            }
        }

        public static bool VerifyPassword(string inputPassword, string salt, string storedHash)
        {
            return HashPassword(inputPassword, salt).Equals(storedHash, StringComparison.OrdinalIgnoreCase);
        }
    }
}
using System;
using System.Data.Common;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CoreStoreCRM
{
    public partial class v : Form
    {
        public v()
        {
            InitializeComponent();
        }

        private void v_Load(object sender, EventArgs e)
        {

        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text.Trim();
            string password = txtPassword.Text;

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                lblError.Text = "Заполните все поля!";
                lblError.Visible = true;
                return;
            }

            using (MySqlConnection conn = DBConnection.GetConnection())
            {
                conn.Open();
                string sql = "SELECT userId, name, roleId, password_salt, password_hash FROM `User` WHERE email = @email";

                using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@email", email);

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string salt = reader.GetString("password_salt");
                            string hash = reader.GetString("password_hash");

                            if (PasswordHelper.VerifyPassword(password, salt, hash))
                            {
                                AppSession.UserId = reader.GetInt32("userId");
                                AppSession.CurrentUserName = reader.GetString("name");
                                AppSession.RoleId = reader.GetInt32("roleId");

                                MainForm mainForm = new MainForm();
                                mainForm.Show();
                                this.Hide();
                            }
                            else
                            {
                                lblError.Text = "Неверный пароль!";
                                lblError.Visible = true;
                            }
                        }
                        else
                        {
                            lblError.Text = "Пользователь не найден!";
                            lblError.Visible = true;
                        }
                    }
                }
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            RegisterForm registerForm = new RegisterForm();
            registerForm.ShowDialog();
        }
    }
}

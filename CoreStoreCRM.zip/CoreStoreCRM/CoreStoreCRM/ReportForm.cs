﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CoreStoreCRM
{
    public partial class ReportForm : Form
    {
        public ReportForm()
        {
            InitializeComponent();
        }

        private void ExecuteQuery(string sql, string title)
        {
            using (MySqlConnection conn = DBConnection.GetConnection())
            {
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter(sql, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvReport.DataSource = dt;
                lblTitle.Text = title;
            }
        }

        private void ReportForm_Load(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            ExecuteQuery("SELECT * FROM v_order_details", "Заказы с деталями (VIEW)");
        }

        private void btnViewStats_Click(object sender, EventArgs e)
        {
            ExecuteQuery("SELECT * FROM v_appeal_statistics", "Статистика обращений (VIEW)");
        }

        private void btnInnerJoin_Click(object sender, EventArgs e)
        {
            string sql = @"SELECT o.orderId, o.startDate, o.amount, u.name as client, os.name as status
                          FROM `Order` o
                          JOIN `User` u ON o.userId = u.userId
                          JOIN OrderStatus os ON o.orderStatusId = os.orderStatusId";
            ExecuteQuery(sql, "INNER JOIN: Заказы с клиентами и статусами");
        }

        private void btnLeftJoin_Click(object sender, EventArgs e)
        {
            string sql = @"SELECT o.orderId, o.address, u.name as client, e.fullName as employee
                          FROM `Order` o
                          LEFT JOIN Employee e ON o.employeeId = e.employeeId
                          JOIN `User` u ON o.userId = u.userId";
            ExecuteQuery(sql, "LEFT JOIN: Все заказы, включая без сотрудника");
        }

        private void btnRightJoin_Click(object sender, EventArgs e)
        {
            string sql = @"SELECT e.fullName, o.orderId, o.startDate
                          FROM `Order` o
                          RIGHT JOIN Employee e ON o.employeeId = e.employeeId";
            ExecuteQuery(sql, "RIGHT JOIN: Все сотрудники, включая без заказов");
        }

        private void btnGroupBy_Click(object sender, EventArgs e)
        {
            string sql = @"SELECT u.name, COUNT(o.orderId) as orderCount, SUM(o.amount) as total
                          FROM `User` u
                          JOIN `Order` o ON u.userId = o.userId
                          GROUP BY u.userId, u.name
                          HAVING COUNT(o.orderId) > 1";
            ExecuteQuery(sql, "GROUP BY + HAVING: Клиенты с 2+ заказами");
        }
    }
}

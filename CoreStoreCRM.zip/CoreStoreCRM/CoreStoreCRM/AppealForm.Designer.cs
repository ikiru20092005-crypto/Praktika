﻿namespace CoreStoreCRM
{
    partial class AppealForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Label lblTitle;
            dgvAppeals = new DataGridView();
            gbEdit = new GroupBox();
            lblDescription = new Label();
            lblType = new Label();
            btnAdd = new Button();
            cmbType = new ComboBox();
            contextMenuStrip1 = new ContextMenuStrip(components);
            txtDescription = new TextBox();
            btnClose = new Button();
            btnRefresh = new Button();
            lblTitle = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvAppeals).BeginInit();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            lblTitle.Location = new Point(12, 9);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(263, 25);
            lblTitle.TabIndex = 3;
            lblTitle.Text = "Управление обращениями";
            // 
            // dgvAppeals
            // 
            dgvAppeals.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAppeals.Location = new Point(281, 33);
            dgvAppeals.Name = "dgvAppeals";
            dgvAppeals.Size = new Size(507, 236);
            dgvAppeals.TabIndex = 4;
            dgvAppeals.CellClick += dgvAppeals_CellClick;
            // 
            // gbEdit
            // 
            gbEdit.Location = new Point(281, 275);
            gbEdit.Name = "gbEdit";
            gbEdit.Size = new Size(507, 172);
            gbEdit.TabIndex = 5;
            gbEdit.TabStop = false;
            gbEdit.Text = "Редактирование";
            // 
            // lblDescription
            // 
            lblDescription.AutoSize = true;
            lblDescription.Location = new Point(12, 59);
            lblDescription.Name = "lblDescription";
            lblDescription.Size = new Size(65, 15);
            lblDescription.TabIndex = 0;
            lblDescription.Text = "Описание:";
            // 
            // lblType
            // 
            lblType.AutoSize = true;
            lblType.Location = new Point(46, 121);
            lblType.Name = "lblType";
            lblType.Size = new Size(31, 15);
            lblType.TabIndex = 6;
            lblType.Text = "Тип:";
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(12, 147);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(87, 46);
            btnAdd.TabIndex = 7;
            btnAdd.Text = "Добавить";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // cmbType
            // 
            cmbType.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbType.FormattingEnabled = true;
            cmbType.Location = new Point(83, 118);
            cmbType.Name = "cmbType";
            cmbType.Size = new Size(192, 23);
            cmbType.TabIndex = 8;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(83, 56);
            txtDescription.Multiline = true;
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(192, 56);
            txtDescription.TabIndex = 10;
            // 
            // btnClose
            // 
            btnClose.Location = new Point(105, 147);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(89, 46);
            btnClose.TabIndex = 11;
            btnClose.Text = "Закрыть (call процедуру)";
            btnClose.UseVisualStyleBackColor = true;
            btnClose.Click += btnClose_Click;
            // 
            // btnRefresh
            // 
            btnRefresh.Location = new Point(200, 147);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(75, 46);
            btnRefresh.TabIndex = 12;
            btnRefresh.Text = "Обновить";
            btnRefresh.UseVisualStyleBackColor = true;
            btnRefresh.Click += btnRefresh_Click;
            // 
            // AppealForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnRefresh);
            Controls.Add(btnClose);
            Controls.Add(txtDescription);
            Controls.Add(cmbType);
            Controls.Add(btnAdd);
            Controls.Add(lblType);
            Controls.Add(lblDescription);
            Controls.Add(gbEdit);
            Controls.Add(dgvAppeals);
            Controls.Add(lblTitle);
            Name = "AppealForm";
            Text = "AppealForm";
            ((System.ComponentModel.ISupportInitialize)dgvAppeals).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvAppeals;
        private GroupBox gbEdit;
        private Label lblDescription;
        private Label lblType;
        private Button btnAdd;
        private ComboBox cmbType;
        private ContextMenuStrip contextMenuStrip1;
        private TextBox txtDescription;
        private Button btnClose;
        private Button btnRefresh;
    }
}
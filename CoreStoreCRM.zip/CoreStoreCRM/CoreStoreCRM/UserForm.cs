﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CoreStoreCRM
{
    public partial class UserForm : Form
    {
        public UserForm()
        {
            InitializeComponent();
        }

        private void UserForm_Load(object sender, EventArgs e)
        {
            if (!AppSession.IsAdmin)
            {
                MessageBox.Show("Доступ запрещен!");
                this.Close();
                return;
            }

            LoadUsers();
        }

        private void LoadUsers()
        {
            using (MySqlConnection conn = DBConnection.GetConnection())
            {
                conn.Open();
                string sql = @"SELECT u.userId, u.email, u.name, u.phone, r.name as roleName 
                              FROM `User` u 
                              JOIN Role r ON u.roleId = r.roleId";

                MySqlDataAdapter adapter = new MySqlDataAdapter(sql, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvUsers.DataSource = dt;
            }
        }
        private void lblTitle_Click(object sender, EventArgs e)
        {

        }
    }
}

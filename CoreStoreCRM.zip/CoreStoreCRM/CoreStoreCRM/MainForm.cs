﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CoreStoreCRM
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void panelStats_Paint(object sender, PaintEventArgs e)
        {

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            lblWelcome.Text = $"Добро пожаловать, {AppSession.CurrentUserName}!";
            lblUserInfo.Text = $"Роль: {AppSession.CurrentRoleName}";


            if (!AppSession.IsAdmin)
            {
                btnUsers.Visible = false;
                btnReports.Visible = false;
                btnReferences.Visible = false;
            }

            LoadStatistics();
        }
        private void LoadStatistics()
        {
            using (MySqlConnection conn = DBConnection.GetConnection())
            {
                conn.Open();

                // Количество заказов
                using (MySqlCommand cmd = new MySqlCommand("SELECT COUNT(*) FROM `Order`", conn))
                {
                    lblOrderCount.Text = $"Всего заказов: {cmd.ExecuteScalar()}";
                }

                // Количество обращений
                using (MySqlCommand cmd = new MySqlCommand("SELECT COUNT(*) FROM Appeal", conn))
                {
                    lblAppealCount.Text = $"Всего обращений: {cmd.ExecuteScalar()}";
                }
            }
        }

        private void btnOrders_Click(object sender, EventArgs e)
        {
            OrderForm orderForm = new OrderForm();
            orderForm.ShowDialog();
        }

        private void btnAppeals_Click(object sender, EventArgs e)
        {
            AppealForm appealForm = new AppealForm();
            appealForm.ShowDialog();
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            ReportForm reportForm = new ReportForm();
            reportForm.ShowDialog();
        }

        private void btnReferences_Click(object sender, EventArgs e)
        {
            ReferenceForm refForm = new ReferenceForm();
            refForm.ShowDialog();
        }

        private void btnUsers_Click(object sender, EventArgs e)
        {
            if (AppSession.IsAdmin)
            {
                UserForm userForm = new UserForm();
                userForm.ShowDialog();
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            AppSession.Logout();
            v loginForm = new v();
            loginForm.Show();
            this.Close();
        }
    }
}

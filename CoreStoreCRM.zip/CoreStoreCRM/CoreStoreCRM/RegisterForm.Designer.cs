﻿namespace CoreStoreCRM
{
    partial class RegisterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitle = new Label();
            label2 = new Label();
            txtPassword = new TextBox();
            lblPassword = new Label();
            txtEmail = new TextBox();
            lblEmail = new Label();
            lblName = new Label();
            txtName = new TextBox();
            txtPhone = new TextBox();
            label4 = new Label();
            btnRegister = new Button();
            btnCancel = new Button();
            lblError = new Label();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            lblTitle.Location = new Point(346, 9);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(109, 21);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Регистрация";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(232, 70);
            label2.Name = "label2";
            label2.Size = new Size(0, 15);
            label2.TabIndex = 1;
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(322, 117);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(163, 23);
            txtPassword.TabIndex = 8;
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Location = new Point(264, 120);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(52, 15);
            lblPassword.TabIndex = 7;
            lblPassword.Text = "Пароль:";
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(322, 88);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(163, 23);
            txtEmail.TabIndex = 6;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(272, 91);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(44, 15);
            lblEmail.TabIndex = 5;
            lblEmail.Text = "Почта:";
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(282, 149);
            lblName.Name = "lblName";
            lblName.Size = new Size(34, 15);
            lblName.TabIndex = 9;
            lblName.Text = "Имя:";
            // 
            // txtName
            // 
            txtName.Location = new Point(322, 146);
            txtName.Name = "txtName";
            txtName.Size = new Size(163, 23);
            txtName.TabIndex = 10;
            // 
            // txtPhone
            // 
            txtPhone.Location = new Point(322, 175);
            txtPhone.Name = "txtPhone";
            txtPhone.Size = new Size(163, 23);
            txtPhone.TabIndex = 12;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(257, 178);
            label4.Name = "label4";
            label4.Size = new Size(59, 15);
            label4.TabIndex = 11;
            label4.Text = "Телефон:";
            // 
            // btnRegister
            // 
            btnRegister.Location = new Point(322, 204);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(163, 35);
            btnRegister.TabIndex = 13;
            btnRegister.Text = "Зарегестрироваться";
            btnRegister.UseVisualStyleBackColor = true;
            btnRegister.Click += btnRegister_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(257, 204);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(59, 35);
            btnCancel.TabIndex = 14;
            btnCancel.Text = "Отмена";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // lblError
            // 
            lblError.AutoSize = true;
            lblError.ForeColor = Color.Red;
            lblError.Location = new Point(257, 272);
            lblError.Name = "lblError";
            lblError.Size = new Size(38, 15);
            lblError.TabIndex = 15;
            lblError.Text = "label1";
            lblError.Visible = false;
            // 
            // RegisterForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblError);
            Controls.Add(btnCancel);
            Controls.Add(btnRegister);
            Controls.Add(txtPhone);
            Controls.Add(label4);
            Controls.Add(txtName);
            Controls.Add(lblName);
            Controls.Add(txtPassword);
            Controls.Add(lblPassword);
            Controls.Add(txtEmail);
            Controls.Add(lblEmail);
            Controls.Add(label2);
            Controls.Add(lblTitle);
            Name = "RegisterForm";
            Text = "RegisterForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitle;
        private Label label2;
        private TextBox txtPassword;
        private Label lblPassword;
        private TextBox txtEmail;
        private Label lblEmail;
        private Label lblName;
        private TextBox txtName;
        private TextBox txtPhone;
        private Label label4;
        private Button btnRegister;
        private Button btnCancel;
        private Label lblError;
    }
}
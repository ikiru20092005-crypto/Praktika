﻿namespace CoreStoreCRM
{
    partial class OrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Label lblTitle;
            dgvOrders = new DataGridView();
            gbEdit = new GroupBox();
            txtAddress = new TextBox();
            cmbStatus = new ComboBox();
            btnAdd = new Button();
            txtAmount = new TextBox();
            lblAddress = new Label();
            lblAmount = new Label();
            lblStatus = new Label();
            lblEmployee = new Label();
            cmbEmployee = new ComboBox();
            btnUpdate = new Button();
            btnRefresh = new Button();
            btnDelete = new Button();
            lblTitle = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvOrders).BeginInit();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            lblTitle.Location = new Point(12, 9);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(214, 25);
            lblTitle.TabIndex = 2;
            lblTitle.Text = "Управление заказами";
            // 
            // dgvOrders
            // 
            dgvOrders.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvOrders.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvOrders.Location = new Point(271, 46);
            dgvOrders.Name = "dgvOrders";
            dgvOrders.Size = new Size(1160, 211);
            dgvOrders.TabIndex = 3;
            dgvOrders.CellClick += dgvOrders_CellClick;
            // 
            // gbEdit
            // 
            gbEdit.Location = new Point(271, 263);
            gbEdit.Name = "gbEdit";
            gbEdit.Size = new Size(1160, 175);
            gbEdit.TabIndex = 4;
            gbEdit.TabStop = false;
            gbEdit.Text = "Редактирование";
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(88, 46);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(177, 23);
            txtAddress.TabIndex = 5;
            // 
            // cmbStatus
            // 
            cmbStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbStatus.FormattingEnabled = true;
            cmbStatus.Location = new Point(88, 109);
            cmbStatus.Name = "cmbStatus";
            cmbStatus.Size = new Size(177, 23);
            cmbStatus.TabIndex = 6;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(28, 173);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(112, 39);
            btnAdd.TabIndex = 7;
            btnAdd.Text = "Добавить";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // txtAmount
            // 
            txtAmount.Location = new Point(88, 75);
            txtAmount.Name = "txtAmount";
            txtAmount.Size = new Size(177, 23);
            txtAmount.TabIndex = 8;
            // 
            // lblAddress
            // 
            lblAddress.AutoSize = true;
            lblAddress.Location = new Point(38, 49);
            lblAddress.Name = "lblAddress";
            lblAddress.Size = new Size(43, 15);
            lblAddress.TabIndex = 9;
            lblAddress.Text = "Адрес:";
            // 
            // lblAmount
            // 
            lblAmount.AutoSize = true;
            lblAmount.Location = new Point(33, 78);
            lblAmount.Name = "lblAmount";
            lblAmount.Size = new Size(48, 15);
            lblAmount.TabIndex = 10;
            lblAmount.Text = "Сумма:";
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(33, 112);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(46, 15);
            lblStatus.TabIndex = 11;
            lblStatus.Text = "Статус:";
            // 
            // lblEmployee
            // 
            lblEmployee.AutoSize = true;
            lblEmployee.Location = new Point(12, 147);
            lblEmployee.Name = "lblEmployee";
            lblEmployee.Size = new Size(69, 15);
            lblEmployee.TabIndex = 12;
            lblEmployee.Text = "Сотрудник:";
            // 
            // cmbEmployee
            // 
            cmbEmployee.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbEmployee.FormattingEnabled = true;
            cmbEmployee.Location = new Point(88, 144);
            cmbEmployee.Name = "cmbEmployee";
            cmbEmployee.Size = new Size(177, 23);
            cmbEmployee.TabIndex = 14;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(146, 173);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(119, 39);
            btnUpdate.TabIndex = 15;
            btnUpdate.Text = "Изменить";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnRefresh
            // 
            btnRefresh.Location = new Point(146, 218);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(119, 39);
            btnRefresh.TabIndex = 17;
            btnRefresh.Text = "Обновить";
            btnRefresh.UseVisualStyleBackColor = true;
            btnRefresh.Click += btnRefresh_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(28, 218);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(112, 39);
            btnDelete.TabIndex = 16;
            btnDelete.Text = "Удалить";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // OrderForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1446, 444);
            Controls.Add(btnRefresh);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(cmbEmployee);
            Controls.Add(lblEmployee);
            Controls.Add(lblStatus);
            Controls.Add(lblAmount);
            Controls.Add(lblAddress);
            Controls.Add(txtAmount);
            Controls.Add(btnAdd);
            Controls.Add(cmbStatus);
            Controls.Add(txtAddress);
            Controls.Add(gbEdit);
            Controls.Add(dgvOrders);
            Controls.Add(lblTitle);
            Name = "OrderForm";
            Text = "OrderForm";
            ((System.ComponentModel.ISupportInitialize)dgvOrders).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvOrders;
        private GroupBox gbEdit;
        private TextBox txtAddress;
        private ComboBox cmbStatus;
        private Button btnAdd;
        private TextBox txtAmount;
        private Label lblAddress;
        private Label lblAmount;
        private Label lblStatus;
        private Label lblEmployee;
        private ComboBox cmbEmployee;
        private Button btnUpdate;
        private Button btnRefresh;
        private Button btnDelete;
    }
}
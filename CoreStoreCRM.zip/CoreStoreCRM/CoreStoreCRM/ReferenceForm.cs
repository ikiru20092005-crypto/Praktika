﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CoreStoreCRM
{
    public partial class ReferenceForm : Form
    {
        public ReferenceForm()
        {
            InitializeComponent();
        }

        private void ReferenceForm_Load(object sender, EventArgs e)
        {
            LoadProductTypes();
            LoadUnits();
            LoadCurrencies();
        }
        private void LoadProductTypes()
        {
            using (MySqlConnection conn = DBConnection.GetConnection())
            {
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM ProductType", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvProductType.DataSource = dt;
            }
        }

        private void LoadUnits()
        {
            using (MySqlConnection conn = DBConnection.GetConnection())
            {
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM Unit", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvUnit.DataSource = dt;
            }
        }

        private void LoadCurrencies()
        {
            using (MySqlConnection conn = DBConnection.GetConnection())
            {
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM Currency", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvCurrency.DataSource = dt;
            }
        }
        private void tabPage1_Click(object sender, EventArgs e)
        {

        }
    }
}

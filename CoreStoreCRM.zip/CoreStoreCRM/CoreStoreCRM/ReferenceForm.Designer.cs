﻿namespace CoreStoreCRM
{
    partial class ReferenceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitle = new Label();
            tabControl = new TabControl();
            tabProductType = new TabPage();
            dgvProductType = new DataGridView();
            tabUnit = new TabPage();
            dgvUnit = new DataGridView();
            tabCurrency = new TabPage();
            dgvCurrency = new DataGridView();
            pageSetupDialog1 = new PageSetupDialog();
            tabControl.SuspendLayout();
            tabProductType.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvProductType).BeginInit();
            tabUnit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvUnit).BeginInit();
            tabCurrency.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvCurrency).BeginInit();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            lblTitle.Location = new Point(22, 19);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(117, 21);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Справочники";
            // 
            // tabControl
            // 
            tabControl.Controls.Add(tabProductType);
            tabControl.Controls.Add(tabUnit);
            tabControl.Controls.Add(tabCurrency);
            tabControl.Dock = DockStyle.Fill;
            tabControl.Location = new Point(0, 0);
            tabControl.Name = "tabControl";
            tabControl.SelectedIndex = 0;
            tabControl.Size = new Size(800, 450);
            tabControl.TabIndex = 1;
            // 
            // tabProductType
            // 
            tabProductType.Controls.Add(dgvProductType);
            tabProductType.Location = new Point(4, 24);
            tabProductType.Name = "tabProductType";
            tabProductType.Padding = new Padding(3);
            tabProductType.Size = new Size(792, 422);
            tabProductType.TabIndex = 0;
            tabProductType.Text = "Типы товаров";
            tabProductType.UseVisualStyleBackColor = true;
            tabProductType.Click += tabPage1_Click;
            // 
            // dgvProductType
            // 
            dgvProductType.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProductType.Location = new Point(0, 0);
            dgvProductType.Name = "dgvProductType";
            dgvProductType.Size = new Size(792, 422);
            dgvProductType.TabIndex = 0;
            // 
            // tabUnit
            // 
            tabUnit.Controls.Add(dgvUnit);
            tabUnit.Location = new Point(4, 24);
            tabUnit.Name = "tabUnit";
            tabUnit.Padding = new Padding(3);
            tabUnit.Size = new Size(792, 422);
            tabUnit.TabIndex = 1;
            tabUnit.Text = "Единицы измерения";
            tabUnit.UseVisualStyleBackColor = true;
            // 
            // dgvUnit
            // 
            dgvUnit.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvUnit.Location = new Point(0, 0);
            dgvUnit.Name = "dgvUnit";
            dgvUnit.Size = new Size(792, 422);
            dgvUnit.TabIndex = 1;
            // 
            // tabCurrency
            // 
            tabCurrency.Controls.Add(dgvCurrency);
            tabCurrency.Location = new Point(4, 24);
            tabCurrency.Name = "tabCurrency";
            tabCurrency.Padding = new Padding(3);
            tabCurrency.Size = new Size(792, 422);
            tabCurrency.TabIndex = 2;
            tabCurrency.Text = "Валюты";
            tabCurrency.UseVisualStyleBackColor = true;
            // 
            // dgvCurrency
            // 
            dgvCurrency.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCurrency.Location = new Point(0, 0);
            dgvCurrency.Name = "dgvCurrency";
            dgvCurrency.Size = new Size(792, 422);
            dgvCurrency.TabIndex = 1;
            // 
            // ReferenceForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tabControl);
            Controls.Add(lblTitle);
            Name = "ReferenceForm";
            Text = "ReferenceForm";
            Load += ReferenceForm_Load;
            tabControl.ResumeLayout(false);
            tabProductType.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvProductType).EndInit();
            tabUnit.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvUnit).EndInit();
            tabCurrency.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvCurrency).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitle;
        private TabControl tabControl;
        private TabPage tabUnit;
        private TabPage tabProductType;
        private TabPage tabCurrency;
        private PageSetupDialog pageSetupDialog1;
        private DataGridView dgvProductType;
        private DataGridView dgvUnit;
        private DataGridView dgvCurrency;
    }
}